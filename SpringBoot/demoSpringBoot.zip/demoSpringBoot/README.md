# DEMO WEB SERVICE WITH SPRING BOOT
Autor = Camilo Esteban Ramirez Salas

- Se le agregaron los atributos "documentType", "documentNumber" y "salary" al proyecto, al agregar una nueva persona esta tendrá dichos atributos.
  
- El nuevo endpoint creado es `/lowest-salary` este devuelve a la persona que tiene el salario mas bajo, en caso de ser mas de 1 las personas que tienen el salario mas bajo devuelve una lista con estas personas. la URL que se debe utilizar para acceder este metodo es _localhost:8080/prog2/202214307/people/lowest-salary_

- En el documento __person.json__ está la información de las personas, en este se comprobó el correcto funcionamiento de los metodos /add, /all, /id, /id/{id} y /lowest-salary.

