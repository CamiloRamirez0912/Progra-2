## GUI EVALUATION

## Autor
German Amezquita Becerra


## prerequisites
- Jdk 17

## Description
Este proyecto contiene un ejemplo del uso de layouts y componentes Swing.

- Menú vertical donde los ítems tienen componentes curvos.
- En el marco principal, se trabaja inicialmente con el cambio de paneles.
- Manejo de colores y personalización del componente JColorChooser.
- Personalización del componente JToggleButton.


<a href="https://www.flaticon.com/free-icons/aligment" title="aligment icons">Aligment icons created by Erix - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/aligment" title="aligment icons">Aligment icons created by Erix - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/alignment" title="alignment icons">Alignment icons created by Arafat Uddin - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/alignment" title="alignment icons">Alignment icons created by Royyan Wijaya - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/interlining" title="interlining icons">Interlining icons created by The Icon Tree - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/thickness" title="thickness icons">Thickness icons created by iconographics - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/thickness" title="thickness icons">Thickness icons created by iconading - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/indent" title="indent icons">Indent icons created by GelsoDesigns - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/indent" title="indent icons">Indent icons created by GelsoDesigns - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/ui" title="ui icons">Ui icons created by Handicon - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/line-spacing" title="line spacing icons">Line spacing icons created by Ilham Fitrotul Hayat - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/letter-a" title="letter a icons">Letter a icons created by Md Tanvirul Haque - Flaticon</a>

<a href="https://www.flaticon.com/free-icons/alphabet" title="alphabet icons">Alphabet icons created by Freepik - Flaticon</a>