## GUI EVALUATION

## Autor
German Amezquita Becerra


## prerequisites
- Jdk 17

## Description
Este proyecto contiene un ejemplo del uso de layouts y componentes Swing.

- Menú vertical donde los ítems tienen componentes curvos.
- En el marco principal, se trabaja inicialmente con el cambio de paneles.
- Manejo de colores y personalización del componente JColorChooser.
- Personalización del componente JToggleButton.