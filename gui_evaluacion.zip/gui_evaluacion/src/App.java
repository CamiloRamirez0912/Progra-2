import co.edu.uptc.views.MainFrame;

public class App {
    public static void main(String[] args) throws Exception {
        
         MainFrame.getInstance();
    }
}
