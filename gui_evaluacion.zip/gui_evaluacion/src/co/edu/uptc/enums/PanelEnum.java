package co.edu.uptc.enums;

public enum PanelEnum {
    DEFAULT, 
    MAIN,
    VEHICLE_MANAGER, 
    STYLE_MODIFIER,
    
}
