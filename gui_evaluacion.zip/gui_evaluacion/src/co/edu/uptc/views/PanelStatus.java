package co.edu.uptc.views;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JPanel;

public class PanelStatus extends JPanel {

  public PanelStatus() {
    setPreferredSize(new Dimension(100, 30));
    setBackground(Color.white);
  }
}
