package co.edu.uptc.views;

import java.awt.Font;

public class FontPalette {
    public static Font MAIN_MENU_FONT = new Font("Arial", Font.BOLD, 14);
    public static Font TITLE_FONT = new Font("Verdana", Font.PLAIN, 20);    
    //public static Font SECONDARY_MENU_FONT = new Font("Verdana", Font.PLAIN, 12);
    //public static Font STATUS_BAR_FONT = new Font("Tahoma", Font.ITALIC, 10);
}
