package co.edu.uptc.views;

import java.awt.*;
import javax.swing.*;

public class PanelModifyStyle extends JPanel{
    private JComboBox<String> fontCombo;
    private JToggleButton boldButton, italicButton, underlineButton;
    private JComboBox<String> alignmentCombo;
    private JTextArea previewArea;

    public PanelModifyStyle() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        initComponents();
    }

    private void initComponents() {
        add(createPropertiesPanel(), BorderLayout.NORTH);
        add(createFormatPanel(), BorderLayout.CENTER);
        add(createPreviewPanel(), BorderLayout.SOUTH);
    }

    private JPanel createPropertiesPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Nombre:"), gbc);

        gbc.gridx = 1;
        JTextField nameField = new JTextField(20);
        panel.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Tipo de estilo:"), gbc);

        gbc.gridx = 1;
        JComboBox<String> styleTypeCombo = new JComboBox<>(new String[] { "Párrafo" });
        panel.add(styleTypeCombo, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Estilo basado en:"), gbc);

        gbc.gridx = 1;
        JComboBox<String> basedOnCombo = new JComboBox<>(new String[] { "Normal" });
        panel.add(basedOnCombo, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Estilo del párrafo siguiente:"), gbc);

        gbc.gridx = 1;
        JComboBox<String> nextParagraphCombo = new JComboBox<>(new String[] { "Normal" });
        panel.add(nextParagraphCombo, gbc);

        return panel;
    }

    private JPanel createFormatPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Formato"));

        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        fontCombo = new JComboBox<>(new String[] { "Calibri (Cuerpo)" });
        boldButton = new JToggleButton("N");
        italicButton = new JToggleButton("K");
        underlineButton = new JToggleButton("S");
        alignmentCombo = new JComboBox<>(new String[] { "Izquierda", "Centro", "Derecha", "Justificar" });

        buttonsPanel.add(fontCombo);
        buttonsPanel.add(boldButton);
        buttonsPanel.add(italicButton);
        buttonsPanel.add(underlineButton);
        buttonsPanel.add(alignmentCombo);

        panel.add(buttonsPanel, BorderLayout.NORTH); 

        JTextArea exampleText = new JTextArea(3, 30); 
        exampleText.setText("Texto de ejemplo Texto de ejemplo Texto de ejemplo Texto de ejemplo Texto de ejemplo  Texto de ejemplo Texto de ejemplo Texto de ejemplo Texto de ejemplo Texto de ejemplo Texto de ejemplo Texto de ejemplo Texto de ejemplo Texto de ejemplo Texto de ejemplo");
        exampleText.setEditable(false);
        exampleText.setLineWrap(true);
        exampleText.setWrapStyleWord(true);

        panel.add(new JScrollPane(exampleText), BorderLayout.CENTER);

        return panel;
    }

    private JPanel createPreviewPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder(""));

        previewArea = new JTextArea(5, 30);
        previewArea.setText("Fuente: (Predeterminadq) + Cuerpo(Cabril), Izquierda" + "\n"
        + "   Interlineado: Múltiple 1,08 lin., Espacio" + "\n"
        + "   Después: 8 pto, Control de líneas viudas y huérfanas, Estilo: Mostrar en la galeria de estilos" + "\n");
        previewArea.setLineWrap(true);
        previewArea.setWrapStyleWord(true);
        previewArea.setEditable(false);

        panel.add(new JScrollPane(previewArea), BorderLayout.CENTER);

        return panel;
    }

    
}
