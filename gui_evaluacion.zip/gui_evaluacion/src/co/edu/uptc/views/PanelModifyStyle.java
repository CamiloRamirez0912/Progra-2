package co.edu.uptc.views;

import java.awt.*;
import javax.swing.*;

public class PanelModifyStyle extends JPanel{
    public PanelModifyStyle(){
        setBackground(Color.WHITE);
        setLayout(new BorderLayout(20,0));
        initComponents();
    }

    private void initComponents(){
        addProperties();
        addSpacing();
    }

    private void addProperties(){
        JPanel properties = new JPanel(new GridLayout(2,0));
        properties.setLayout(new FlowLayout());
        JPanel labels = labelPanel();
        JPanel text = textPanel();
        properties.add(labels);
        properties.add(text);
        add(properties);
    }

    private JPanel labelPanel(){
        JPanel labelsPanel = new JPanel(new GridLayout(4, 0));
        JLabel name = new JLabel("Nombre:");
        JLabel style = new JLabel("Tipo de estilo:");
        JLabel basedStyle = new JLabel("Estilo basado en:");
        JLabel nextPar = new JLabel("Estilo del párrafo siguiente:");
        labelsPanel.add(name);
        labelsPanel.add(style);
        labelsPanel.add(basedStyle);
        labelsPanel.add(nextPar);
        return labelsPanel;
    }

    private JPanel textPanel(){
        JPanel texts = new JPanel(new GridLayout(4, 0));
        JTextField name = new JTextField();
        name.setSize(Integer.MAX_VALUE,50);
        JTextField style = new JTextField();
        JTextField basedStyle = new JTextField();
        JTextField nextPar = new JTextField();
        texts.add(name);
        texts.add(style);
        texts.add(basedStyle);
        texts.add(nextPar);
        return texts;
    }

    private void addSpacing(){
        JPanel topSpace = new JPanel();
        topSpace.setOpaque(false);
        topSpace.setPreferredSize(new Dimension(1, 40));

        add(topSpace, BorderLayout.NORTH);

        JPanel leftSpace = new JPanel();
        leftSpace.setOpaque(false);
        leftSpace.setPreferredSize(new Dimension(28, 1));
        add(leftSpace, BorderLayout.WEST);
    }

    
}
