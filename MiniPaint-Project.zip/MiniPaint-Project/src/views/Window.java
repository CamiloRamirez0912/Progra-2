package views;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Window extends JFrame {

        private MenuOptions menuOptions;
        private ToolbarPanel toolbarPanel;
        private DrawingBoard drawingBoard;
        private BottomPanel bottomPanel;

        public Window() {
                setLayout(new BorderLayout());
                setExtendedState(JFrame.MAXIMIZED_BOTH);
                getContentPane().setBackground(Color.CYAN);

                // Initialize components
                menuOptions = new MenuOptions();
                toolbarPanel = new ToolbarPanel();
                drawingBoard = new DrawingBoard();
                bottomPanel = new BottomPanel();

                // Set up the main menu
                setJMenuBar(menuOptions);

                // Add components to the frame
                add(toolbarPanel, BorderLayout.NORTH);
                add(drawingBoard, BorderLayout.CENTER);
                add(bottomPanel, BorderLayout.SOUTH);

                // Set up KeyBindings for F11
                setupKeyBindings();

                // Set default close operation
                setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        }

        private void setupKeyBindings() {
                JRootPane rootPane = getRootPane();
                InputMap inputMap = rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
                ActionMap actionMap = rootPane.getActionMap();

                inputMap.put(KeyStroke.getKeyStroke(KeyEvent.VK_F11, 0), "toggleToolbar");
                actionMap.put("toggleToolbar", new AbstractAction() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                                toolbarPanel.toggleVisibility();
                        }
                });
        }
}