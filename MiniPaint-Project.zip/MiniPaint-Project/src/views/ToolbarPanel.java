package views;

import javax.swing.*;
import java.awt.*;
import java.awt.image.*;

public class ToolbarPanel extends JPanel {
    private JToolBar toolbar;
    private final int BUTTON_SIZE = 50;

    public ToolbarPanel() {
        setLayout(new BorderLayout());
        createToolbar();
        add(toolbar, BorderLayout.CENTER);
    }

    private void createToolbar() {
        toolbar = new JToolBar();
        toolbar.setFloatable(false);

        JPanel firstSection = new JPanel();
        firstSection.add(createToolbarButton("src/assets/linea.jpeg"));
        firstSection.add(createToolbarButton("src/assets/circulo.jpeg"));
        firstSection.add(createToolbarButton("src/assets/cuadrado.jpg"));
        firstSection.add(createToolbarButton("src/assets/borrador.jpeg"));

        JPanel secondSection = new JPanel();
        secondSection.add(createToolbarButton("src/assets/rojo.png"));
        secondSection.add(createToolbarButton("src/assets/azul.png"));
        secondSection.add(createToolbarButton("src/assets/verde.png"));

        toolbar.add(firstSection);
        toolbar.addSeparator(new Dimension(15, 0));
        toolbar.add(secondSection);
    }

    private JButton createToolbarButton(String iconPath) {
        ImageIcon originalIcon = new ImageIcon(iconPath);
        Image resizedImage = getScaledImage(originalIcon.getImage(), BUTTON_SIZE, BUTTON_SIZE);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);

        JButton button = new JButton(resizedIcon);
        button.setPreferredSize(new Dimension(BUTTON_SIZE, BUTTON_SIZE));
        button.setFocusPainted(false);
        return button;
    }

    private Image getScaledImage(Image srcImg, int width, int height) {
        BufferedImage resizedImg = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = resizedImg.createGraphics();

        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(srcImg, 0, 0, width, height, null);
        g2.dispose();

        return resizedImg;
    }

    public void toggleVisibility(){
        setVisible(!isVisible());
    }
}