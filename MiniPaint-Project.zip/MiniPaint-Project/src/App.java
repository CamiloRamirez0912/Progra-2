import views.Window;

public class App {
    public static void main(String[] args){
        Window window = new Window();
        window.setVisible(true);
    }
}
