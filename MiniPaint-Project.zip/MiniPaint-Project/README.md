# Proyecto MiniPaint

## Paleta de Colores

Nuestro proyecto MiniPaint utiliza la siguiente paleta de colores:

### a. Color Base (Fondo Principal):
- Azul Claro: `#E1F0FA` (Fondo del panel y menú)

### b. Color Principal del Texto:
- Negro: `#000000` (Color del texto del panel inferior y canvas)

### c. Colores de Acento:
- Gris Claro: `#F7F7F7` (Fondo del lienzo)

### d. Colores de Fondo Secundario:
- Blanco: `#FFFFFF` (Fondo de los botones y menú)

### e. Color de Sombra o Borde:
- Gris Claro: `#CED4DA` (Borde en el panel inferior)

## Especificaciones de Fuente
- Arial, tamaño 16, bold

### Para Encabezados:
- **Familia de Fuente:** Arial  
- **Estilo:** Negrita  
- **Tamaño:** 16px  

### Para Texto del Cuerpo:
- **Familia de Fuente:** Arial  
- **Estilo:** Regular  
- **Tamaño:** 14px  

### Para Botones y Elementos del Menú:
- **Familia de Fuente:** Arial  
- **Estilo:** Negrita  
- **Tamaño:** 16px  

## Estructura del Proyecto

El proyecto MiniPaint consta de los siguientes componentes principales:

- **Window:** La ventana principal de la aplicación.
- **MenuOptions:** La barra de menú superior con opciones de configuración.
- **DrawingBoard:** El lienzo central donde se realizan los dibujos.
- **BottomPanel:** Muestra el color actual y el conteo de elementos.
- **VerticalMenuPanel:** Menú vertical en la parte izquierda de la pantalla con submenús de configuración y herramientas.
- **ToolBarPanel:** Barra de herramientas en la parte superior, abajo del menú principal de la pantalla, contiene herramientas y selección de colores.

## Cómo Ejecutar
Para poder ejecutar la aplicación se debe estar ubicado en la carpeta `MiniPaint-Project`
luego se ejecuta el siguiente comando: ```java -jar executable/paint-project.jar```

## Versión Mínima
java 21.0.4 2024-07-16 LTS

### Resumen de los cambios:  
**Actualización de versión**: Se creó una barra de herramientas que contiene 7 botones, 4 son para dibujo como lineas, circulos, cuadrados y para borrar, las otras 3 son para seleccionar el color. Tambien se adicionó un KeyListener para que al presionar la tecla F11 se oculte o muestre la barra de herramientas.

## Colaboradores

- Camilo Ramirez 202214307

**Última Actualización:** 16/09/2024